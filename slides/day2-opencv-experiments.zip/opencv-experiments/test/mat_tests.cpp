#include <gtest/gtest.h>

#include <opencv2/core/core.hpp>

using namespace cv;
using namespace std;

// TEST(signed_char, smallest_number)
// {
//     signed char c = -127;
//     EXPECT_EQ(128, int(c - 1));
// }

TEST(Mat, demo)
{
    Mat m(4, 6, CV_8UC1);
    randu(m, 0, 255);

    cout << m.size() << endl;
    cout << m.cols << endl;
    cout << m.rows << endl;
    cout << m.step << endl;

    cout << endl;
    cout << m << endl;

    Rect region(2, 2, 2, 2);
    Mat submat = m(region);

    cout << submat << endl;
    EXPECT_EQ(m.step, submat.step);

    submat.at<uchar>(0, 0) = 0;
    cout << m << endl;

    Mat m2 = m;
    m2.at<uchar>(0, 0) = 0;
    cout << m << endl;

    Mat m3 = m.clone();
    m3.at<uchar>(0, 1) = 0;
    cout << m << endl;
    cout << m3 << endl;

    cout << int(m.data[3]) << endl;
    EXPECT_EQ(m2.data, m.data);
    EXPECT_NE(m3.data, m.data);

    cout << m.type() << endl;
}

TEST(Mat, assignment_doesnt_copy_data)
{
    Mat m1(10, 10, CV_8UC1);
    Mat m2 = m1;

    EXPECT_EQ(m1.data, m2.data);
}

TEST(Mat, clone_does_copy_data)
{
    Mat m1(10, 10, CV_8UC1);
    Mat m2 = m1.clone();

    EXPECT_NE(m1.data, m2.data);
}

TEST(Mat, matrices_use_same_data)
{
    Mat m1(10, 10, CV_8UC1);
    m1.setTo(128);

    Mat m2 = m1;
    m1.setTo(0);

    EXPECT_EQ(sum(m2), Scalar(0.0));
}

TEST(Mat, submat_uses_same_memory)
{
    Mat m1(10, 10, CV_8UC1);
    m1.setTo(128);

    Rect roi(0, 0, m1.cols, m1.rows/2);
    Mat m2 = m1(roi);
    m2.setTo(0);

    EXPECT_EQ(sum(m1), Scalar(128 * 5 * 10));
}

TEST(Mat, step_of_submat_is_equal_to_mat_width)
{
    Mat m1(10, 10, CV_8UC1);

    Rect roi(3, 3, 2, 4);
    Mat m2 = m1(roi);

    EXPECT_EQ(m2.step, m1.cols);
}

TEST(Mat, can_work_with_row)
{
    Mat m1(10, 10, CV_8UC1);
    m1.setTo(1);
    EXPECT_EQ(sum(m1), Scalar(100, 0, 0));

    Mat row = m1.row(3);
    row.setTo(0);
    EXPECT_EQ(sum(m1), Scalar(90));
}

TEST(Mat, can_access_pixels)
{
    Mat m1(10, 10, CV_8UC1);
    m1.setTo(1);
    EXPECT_EQ(sum(m1), Scalar(100));

    m1.at<uchar>(3, 3) = 0;
    m1.at<uchar>(4, 4) = 0;
    m1.at<uchar>(5, 5) = 0;

    EXPECT_EQ(sum(m1), Scalar(97));
}

TEST(Mat, can_get_mask_of_differences)
{
    Mat m1(10, 10, CV_8UC1);
    m1.setTo(1);
    EXPECT_EQ(sum(m1), Scalar(100));

    Mat m2 = m1.clone();
    m2.at<uchar>(3, 3) = 0;
    m2.at<uchar>(4, 4) = 0;
    m2.at<uchar>(5, 5) = 0;

    Mat mask = (m1 != m2);

    EXPECT_EQ(3, countNonZero(mask));
}

TEST(Mat, can_get_mask_of_differences2)
{
    Mat m1(10, 10, CV_8UC1);
    m1.setTo(1);
    EXPECT_EQ(sum(m1), Scalar(100));

    Mat m2 = m1.clone();
    m2.at<uchar>(3, 3) = 0;
    m2.at<uchar>(4, 4) = 0;
    m2.at<uchar>(5, 5) = 0;

    Mat mask = (m2 > m1);

    EXPECT_EQ(0, countNonZero(mask));
}

TEST(Mat, can_multiply_with_scalar)
{
    Mat m1(10, 10, CV_8UC1);
    m1.setTo(2);

    Mat m2 = m1 * 2;

    Mat m3 = m1.clone();
    m3.setTo(4);

    EXPECT_EQ(0, countNonZero(m2 - m3));
}

TEST(Mat, can_split_mat)
{
    Mat m1(10, 10, CV_8UC3);
    m1.setTo(Scalar(1, 2, 3));

    vector<Mat> channels;
    split(m1, channels);

    EXPECT_EQ(3, channels.size());
    EXPECT_EQ(1, channels[0].channels());
    EXPECT_EQ(Scalar(1 * 10 * 10), sum(channels[0]));
    EXPECT_EQ(Scalar(2 * 10 * 10), sum(channels[1]));
    EXPECT_EQ(Scalar(3 * 10 * 10), sum(channels[2]));
}

TEST(Mat, can_merge_mat)
{
    Mat r(10, 10, CV_8UC1, Scalar(1));
    Mat g(10, 10, CV_8UC1, Scalar(2));
    Mat b(10, 10, CV_8UC1, Scalar(3));

    vector<Mat> channels;
    channels.push_back(r);
    channels.push_back(g);
    channels.push_back(b);

    Mat m;
    merge(channels, m);

    EXPECT_EQ(3, m.channels());
    EXPECT_EQ(Scalar(100, 200, 300), sum(m));
}

TEST(Mat, saturation_is_used)
{
    Mat m1(10, 10, CV_8UC3, Scalar(200));
    Mat m2(10, 10, CV_8UC3, Scalar(200));

    Mat m3 = m1 + m2;
    EXPECT_EQ(255, m3.at<uchar>(0, 0));

    m2.setTo(255);
    m3 = m1 - m2;
    EXPECT_EQ(0, m3.at<uchar>(0, 0));
}

TEST(Mat, can_creat_identity_mat)
{
    Mat m1 = Mat::eye(10, 10, CV_8UC1);
    EXPECT_EQ(Scalar(10), sum(m1));

    // Mat m2 = m1.convertTo(CV_32FC1);
    // EXPECT_EQ(0, countNonZero(m2*m2 - m2));
}

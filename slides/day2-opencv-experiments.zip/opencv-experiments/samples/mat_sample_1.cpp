#include "opencv2/opencv.hpp"

using namespace cv;

int main(int argc, char** argv)
{
    Mat img, gray, edges;
    img = imread(argv[1], 1);
    imshow("original", img);

    Mat hsv;
    cvtColor(img, hsv, COLOR_BGR2HSV);
    vector<Mat> channels;
    split(hsv, channels);
    Mat v = channels[2];

    // GaussianBlur(v, v, Size(7, 7), 1.5);
    Canny(v, edges, 0, 50);

    imwrite("result.png", edges);

    imshow("edges", edges);
    imshow("v", v);
    waitKey();

    return 0;
}

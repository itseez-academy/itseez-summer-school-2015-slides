#include "opencv2/opencv.hpp"

using namespace cv;

int main(int argc, char** argv)
{
    Mat img, gray, edges;
    // use "VideoCapture cap(argv[1])" to grab from video file
    VideoCapture cap(0);

    for(;;)
    {
        cap >> img;
        if(img.empty())
            break;

        cvtColor(img, gray, COLOR_BGR2GRAY);
        GaussianBlur(gray, gray, Size(3, 3), 1.5);
        Canny(gray, edges, 0, 50);

        imshow("edges", edges);
        if(waitKey(30) >= 0)
            break;
    }

    return 0;
}
